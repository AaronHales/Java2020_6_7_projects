/*
 <Java Programming>
 <ch 4>
 <Chapter 4 activity>
 <First Variables>
 <Aaron Hales>
 <9/27/20>
*/


package aaron.hales.ch4.activity;

public class FirstVariables {

	public FirstVariables() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		
		int my_integer = 34;
		System.out.println("my_integer: " + my_integer);
		
		double my_double = 65.2;
		System.out.println("my_double: " + my_double);
		
		boolean my_boolean = true;
		System.out.println("my_boolean: " + my_boolean);
		
		char my_char = 'A';
		System.out.println("my_char: " + my_char);
		
		String my_string = "Hello!";
		System.out.println("my_string: " + my_string);

	}

}
