/*
	<Java Programming>
	<ch 2 lesson 2>
	<Chapter activity 2>
	<Showtime>
	<Aaron Hales>
	<9/16/20>
*/

package aaron.hales.showtime;
import java.util.Calendar; //imports Calendar

public class ShowTime {

	public ShowTime() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(Calendar.getInstance().getTime()); //gets the date and time

	}

}
